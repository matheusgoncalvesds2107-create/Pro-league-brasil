PRO LEAGUE BRASIL v0.7 - CANDIDATA AO PRIMEIRO APK

Projeto Godot 4 do primeiro GRENAL DOS SECULOS na PLB TV.

FOCO DA v0.7:
- Consolidar a jogabilidade das versoes anteriores
- Limite de 30 FPS / fisica a 30 Hz para celulares fracos
- Camera de transmissao um pouco mais proxima e limitada ao campo
- Partida de teste com 6 minutos e tela de FIM DE JOGO
- Sem sombras pesadas e sem MSAA 3D
- Fogos apenas na abertura; bandeiroes simples
- 11 x 11, IA simples, goleiros, marcacao, disputa e troca de jogador
- Passe, chute e corrida
- Gol, lateral, escanteio, tiro de meta e falta simples
- Abertura e placar PLB TV / GRENAL DOS SECULOS

CONTROLES PC:
WASD = mover
J = passe
K = chute
L = correr
Q = trocar jogador

ANDROID:
Use os botoes na tela.

OBSERVACAO:
Este pacote e o projeto Godot v0.7 preparado para exportacao Android.
O APK ainda precisa ser compilado/exportado em um ambiente com Godot 4 e Android SDK instalados.
