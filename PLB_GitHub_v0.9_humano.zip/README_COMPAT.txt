PLB v0.8 compatível: arm64-v8a + armeabi-v7a, ícone profissional PNG, ETC2/ASTC habilitado.
