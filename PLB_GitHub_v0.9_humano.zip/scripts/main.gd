extends Node3D

var ball: RigidBody3D
var camera: Camera3D
var controlled: CharacterBody3D
var home: Array[CharacterBody3D] = []
var away: Array[CharacterBody3D] = []
var home_pos: Array[Vector3] = []
var away_pos: Array[Vector3] = []
var score_home := 0
var score_away := 0
var match_time := 0.0
var finished := false
var score_label: Label
var time_label: Label
var message_label: Label
var ai_cooldown := 0.0

func _ready():
    Engine.max_fps = 30
    _setup_input()
    _make_world()
    _make_pitch()
    _make_stadium()
    _make_ball()
    _make_teams()
    _make_camera()
    _make_ui()

func _setup_input():
    for action in ["left", "right", "up", "down", "pass", "shoot", "sprint", "switch"]:
        if not InputMap.has_action(action):
            InputMap.add_action(action)

func _make_world():
    var world := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color(0.40, 0.64, 0.86)
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color.WHITE
    env.ambient_light_energy = 0.85
    world.environment = env
    add_child(world)
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-55, -25, 0)
    sun.light_energy = 1.0
    sun.shadow_enabled = false
    add_child(sun)

func _box(size: Vector3, pos: Vector3, color: Color):
    var body := StaticBody3D.new()
    body.position = pos
    var mesh := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = size
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    box.material = mat
    mesh.mesh = box
    body.add_child(mesh)
    var col := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = size
    col.shape = shape
    body.add_child(col)
    add_child(body)

func _make_pitch():
    _box(Vector3(68, 0.2, 105), Vector3(0, -0.15, 0), Color(0.08, 0.46, 0.14))
    for x in [-34.0, 34.0, 0.0]:
        _box(Vector3(0.10, 0.03, 105), Vector3(x, 0.01, 0), Color.WHITE)
    for z in [-52.5, 52.5]:
        _box(Vector3(68, 0.03, 0.10), Vector3(0, 0.01, z), Color.WHITE)
        _box(Vector3(7.4, 0.10, 0.10), Vector3(0, 2.45, z), Color.WHITE)
        _box(Vector3(0.10, 2.5, 0.10), Vector3(-3.7, 1.25, z), Color.WHITE)
        _box(Vector3(0.10, 2.5, 0.10), Vector3(3.7, 1.25, z), Color.WHITE)

func _make_stadium():
    var stand := Color(0.20, 0.22, 0.24)
    _box(Vector3(88, 3, 9), Vector3(0, 1.4, -61), stand)
    _box(Vector3(88, 3, 9), Vector3(0, 1.4, 61), stand)
    _box(Vector3(9, 3, 112), Vector3(-43, 1.4, 0), stand)
    _box(Vector3(9, 3, 112), Vector3(43, 1.4, 0), stand)

func _make_ball():
    ball = RigidBody3D.new()
    ball.position = Vector3(0, 0.45, 0)
    ball.mass = 0.43
    ball.continuous_cd = true
    ball.linear_damp = 0.7
    var mesh := MeshInstance3D.new()
    var sphere := SphereMesh.new()
    sphere.radius = 0.22
    sphere.height = 0.44
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color.WHITE
    sphere.material = mat
    mesh.mesh = sphere
    ball.add_child(mesh)
    var col := CollisionShape3D.new()
    var shape := SphereShape3D.new()
    shape.radius = 0.22
    col.shape = shape
    ball.add_child(col)
    add_child(ball)

func _mesh_part(parent: Node3D, mesh: PrimitiveMesh, pos: Vector3, color: Color, part_name: String = "") -> MeshInstance3D:
    var part := MeshInstance3D.new()
    if part_name != "":
        part.name = part_name
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 0.78
    mesh.material = mat
    part.mesh = mesh
    part.position = pos
    parent.add_child(part)
    return part

func _limb(parent: Node3D, part_name: String, pivot_pos: Vector3, size: Vector3, color: Color) -> Node3D:
    var pivot := Node3D.new()
    pivot.name = part_name
    pivot.position = pivot_pos
    parent.add_child(pivot)
    var box := BoxMesh.new()
    box.size = size
    _mesh_part(pivot, box, Vector3(0, -size.y * 0.5, 0), color)
    return pivot

func _player(pos: Vector3, team: int, index: int) -> CharacterBody3D:
    var p := CharacterBody3D.new()
    p.position = pos
    p.set_meta("team", team)
    p.set_meta("index", index)
    p.set_meta("anim_t", float(index) * 0.31)

    var body := Node3D.new()
    body.name = "HumanBody"
    p.add_child(body)

    var shirt := Color(0.82, 0.035, 0.045) if team == 1 else Color(0.06, 0.23, 0.68)
    var shorts := Color(0.94, 0.94, 0.94) if team == 1 else Color(0.08, 0.08, 0.12)
    var socks := Color(0.82, 0.035, 0.045) if team == 1 else Color(0.94, 0.94, 0.96)
    var skin := Color(0.73, 0.49, 0.34)
    var boot := Color(0.035, 0.035, 0.04)

    # Tronco / camisa
    var torso := BoxMesh.new()
    torso.size = Vector3(0.72, 0.72, 0.34)
    _mesh_part(body, torso, Vector3(0, 1.38, 0), shirt, "Torso")

    # Calção
    var hip := BoxMesh.new()
    hip.size = Vector3(0.62, 0.34, 0.36)
    _mesh_part(body, hip, Vector3(0, 0.93, 0), shorts, "Shorts")

    # Pescoço e cabeça
    var neck := CylinderMesh.new()
    neck.top_radius = 0.105
    neck.bottom_radius = 0.105
    neck.height = 0.16
    _mesh_part(body, neck, Vector3(0, 1.79, 0), skin, "Neck")
    var head := SphereMesh.new()
    head.radius = 0.22
    head.height = 0.44
    _mesh_part(body, head, Vector3(0, 2.03, 0), skin, "Head")
    var hair := SphereMesh.new()
    hair.radius = 0.225
    hair.height = 0.20
    _mesh_part(body, hair, Vector3(0, 2.16, 0), Color(0.055, 0.035, 0.025), "Hair")

    # Braços articulados
    _limb(body, "LeftArm", Vector3(-0.45, 1.68, 0), Vector3(0.18, 0.70, 0.20), shirt)
    _limb(body, "RightArm", Vector3(0.45, 1.68, 0), Vector3(0.18, 0.70, 0.20), shirt)

    # Pernas articuladas: coxa + canela/meião + chuteira
    var ll := _limb(body, "LeftLeg", Vector3(-0.18, 0.82, 0), Vector3(0.25, 0.72, 0.28), skin)
    var rl := _limb(body, "RightLeg", Vector3(0.18, 0.82, 0), Vector3(0.25, 0.72, 0.28), skin)
    var lshin := BoxMesh.new(); lshin.size = Vector3(0.22, 0.54, 0.24)
    _mesh_part(ll, lshin, Vector3(0, -0.98, 0), socks, "LeftSock")
    var rshin := BoxMesh.new(); rshin.size = Vector3(0.22, 0.54, 0.24)
    _mesh_part(rl, rshin, Vector3(0, -0.98, 0), socks, "RightSock")
    var lboot := BoxMesh.new(); lboot.size = Vector3(0.25, 0.14, 0.42)
    _mesh_part(ll, lboot, Vector3(0, -1.28, -0.08), boot, "LeftBoot")
    var rboot := BoxMesh.new(); rboot.size = Vector3(0.25, 0.14, 0.42)
    _mesh_part(rl, rboot, Vector3(0, -1.28, -0.08), boot, "RightBoot")

    # Colisão continua simples e leve; ela não aparece no jogo.
    var col := CollisionShape3D.new()
    var shape := CapsuleShape3D.new()
    shape.radius = 0.34
    shape.height = 1.72
    col.shape = shape
    col.position.y = 0.86
    p.add_child(col)
    add_child(p)
    return p

func _make_teams():
    home_pos = [
        Vector3(0,0,48), Vector3(-22,0,32), Vector3(-8,0,34), Vector3(8,0,34), Vector3(22,0,32),
        Vector3(-20,0,14), Vector3(-7,0,16), Vector3(7,0,16), Vector3(20,0,14), Vector3(-8,0,-4), Vector3(8,0,-4)
    ]
    away_pos = [
        Vector3(0,0,-48), Vector3(-22,0,-32), Vector3(-8,0,-34), Vector3(8,0,-34), Vector3(22,0,-32),
        Vector3(-20,0,-14), Vector3(-7,0,-16), Vector3(7,0,-16), Vector3(20,0,-14), Vector3(-8,0,4), Vector3(8,0,4)
    ]
    for i in range(11):
        home.append(_player(home_pos[i], 1, i))
        away.append(_player(away_pos[i], 2, i))
    controlled = home[9]
    _add_ring(controlled)

func _add_ring(p: CharacterBody3D):
    var ring := MeshInstance3D.new()
    ring.name = "Ring"
    var cyl := CylinderMesh.new()
    cyl.top_radius = 0.55
    cyl.bottom_radius = 0.55
    cyl.height = 0.04
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(1.0, 0.85, 0.05)
    cyl.material = mat
    ring.mesh = cyl
    ring.position.y = 0.03
    p.add_child(ring)

func _make_camera():
    camera = Camera3D.new()
    camera.position = Vector3(21, 13, 15)
    camera.fov = 46
    add_child(camera)
    camera.look_at(Vector3.ZERO, Vector3.UP)

func _make_ui():
    var layer := CanvasLayer.new()
    add_child(layer)
    score_label = Label.new()
    score_label.text = "PLB TV   INT 0 x 0 GRE"
    score_label.position = Vector2(24, 18)
    score_label.add_theme_font_size_override("font_size", 26)
    layer.add_child(score_label)
    time_label = Label.new()
    time_label.text = "00:00"
    time_label.position = Vector2(390, 20)
    time_label.add_theme_font_size_override("font_size", 22)
    layer.add_child(time_label)
    message_label = Label.new()
    message_label.text = "GRENAL DOS SÉCULOS\nPLB TV"
    message_label.position = Vector2(470, 70)
    message_label.size = Vector2(340, 100)
    message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    message_label.add_theme_font_size_override("font_size", 28)
    layer.add_child(message_label)
    _button(layer, "◀", Vector2(30, 590), "left")
    _button(layer, "▶", Vector2(150, 590), "right")
    _button(layer, "▲", Vector2(90, 530), "up")
    _button(layer, "▼", Vector2(90, 650), "down")
    _button(layer, "PASSE", Vector2(980, 620), "pass")
    _button(layer, "CHUTE", Vector2(1110, 545), "shoot")
    _button(layer, "CORRER", Vector2(1110, 650), "sprint")
    _button(layer, "TROCAR", Vector2(980, 545), "switch")

func _button(layer: CanvasLayer, text: String, pos: Vector2, action: String):
    var b := Button.new()
    b.text = text
    b.position = pos
    b.size = Vector2(105, 58)
    b.add_theme_font_size_override("font_size", 20)
    b.button_down.connect(func(): Input.action_press(action))
    b.button_up.connect(func(): Input.action_release(action))
    layer.add_child(b)

func _physics_process(delta):
    if finished:
        return
    match_time += delta
    if match_time >= 360.0:
        _finish()
        return
    ai_cooldown = max(0.0, ai_cooldown - delta)
    _control_player()
    _ai_team(home, 1, delta)
    _ai_team(away, 2, delta)
    _animate_players(delta)
    _ball_actions()
    _check_goal()
    _keep_in_bounds()
    _camera_follow(delta)
    _clock()

func _control_player():
    var input := Input.get_vector("left", "right", "up", "down")
    var move := Vector3(input.x, 0, input.y)
    var speed := 10.0 if Input.is_action_pressed("sprint") else 7.0
    controlled.velocity = move * speed
    if move.length() > 0.05:
        controlled.look_at(controlled.global_position + move, Vector3.UP)
    controlled.move_and_slide()
    _clamp(controlled)
    if Input.is_action_just_pressed("pass"):
        _kick(controlled, 9.5, 0.8)
    if Input.is_action_just_pressed("shoot"):
        _kick(controlled, 16.5, 2.5)
    if Input.is_action_just_pressed("switch"):
        _switch_player()

func _ai_team(arr: Array[CharacterBody3D], team: int, delta: float):
    var nearest := _nearest(arr, ball.global_position, controlled if team == 1 else null)
    for i in range(arr.size()):
        var p := arr[i]
        if p == controlled:
            continue
        var base: Vector3 = home_pos[i] if team == 1 else away_pos[i]
        var target := base
        if p == nearest:
            target = ball.global_position
        elif i > 0:
            target.z += clamp(ball.global_position.z * 0.18, -9.0, 9.0)
        var d := target - p.global_position
        d.y = 0
        p.velocity = d.normalized() * (6.2 if p == nearest else 4.0) if d.length() > 0.7 else Vector3.ZERO
        if p.velocity.length() > 0.1:
            p.look_at(p.global_position + p.velocity, Vector3.UP)
        p.move_and_slide()
        _clamp(p)

func _animate_players(delta: float):
    for p in home + away:
        var body := p.get_node_or_null("HumanBody")
        if body == null:
            continue
        var t := float(p.get_meta("anim_t")) + delta * (7.5 if p.velocity.length() > 0.4 else 2.0)
        p.set_meta("anim_t", t)
        var amount := 0.62 if p.velocity.length() > 0.4 else 0.04
        var swing := sin(t) * amount
        var left_leg := body.get_node_or_null("LeftLeg")
        var right_leg := body.get_node_or_null("RightLeg")
        var left_arm := body.get_node_or_null("LeftArm")
        var right_arm := body.get_node_or_null("RightArm")
        if left_leg: left_leg.rotation.x = swing
        if right_leg: right_leg.rotation.x = -swing
        if left_arm: left_arm.rotation.x = -swing * 0.72
        if right_arm: right_arm.rotation.x = swing * 0.72

func _ball_actions():
    if ai_cooldown > 0.0:
        return
    for p in home + away:
        if p == controlled:
            continue
        if p.global_position.distance_to(ball.global_position) < 1.25:
            var team := int(p.get_meta("team"))
            var goal := Vector3(0, 0, -53) if team == 1 else Vector3(0, 0, 53)
            var dir := (goal - p.global_position).normalized()
            ball.linear_velocity = dir * (15.0 if p.global_position.distance_to(goal) < 25.0 else 8.0) + Vector3.UP * 1.2
            ai_cooldown = 0.6
            return

func _kick(p: CharacterBody3D, power: float, lift: float):
    if p.global_position.distance_to(ball.global_position) > 2.3:
        return
    var dir := -p.global_transform.basis.z.normalized()
    ball.linear_velocity = dir * power + Vector3.UP * lift

func _nearest(arr: Array[CharacterBody3D], target: Vector3, exclude: CharacterBody3D) -> CharacterBody3D:
    var best: CharacterBody3D = null
    var best_d := INF
    for p in arr:
        if p == exclude:
            continue
        var d := p.global_position.distance_squared_to(target)
        if d < best_d:
            best_d = d
            best = p
    return best

func _switch_player():
    var next := _nearest(home, ball.global_position, controlled)
    if next == null:
        return
    var ring := controlled.get_node_or_null("Ring")
    if ring:
        ring.queue_free()
    controlled = next
    _add_ring(controlled)

func _check_goal():
    if abs(ball.global_position.x) > 3.8 or ball.global_position.y > 2.8:
        return
    if ball.global_position.z < -53.0:
        score_home += 1
        _reset("GOL DO INTER!")
    elif ball.global_position.z > 53.0:
        score_away += 1
        _reset("GOL DO GRÊMIO!")

func _reset(text: String):
    message_label.text = text
    score_label.text = "PLB TV   INT %d x %d GRE" % [score_home, score_away]
    ball.linear_velocity = Vector3.ZERO
    ball.angular_velocity = Vector3.ZERO
    ball.position = Vector3(0, 0.45, 0)
    for i in range(11):
        home[i].position = home_pos[i]
        away[i].position = away_pos[i]

func _keep_in_bounds():
    if ball.global_position.y < -2.0 or abs(ball.global_position.x) > 38.0 or abs(ball.global_position.z) > 58.0:
        ball.linear_velocity = Vector3.ZERO
        ball.position = Vector3(clamp(ball.global_position.x, -31.0, 31.0), 0.45, clamp(ball.global_position.z, -49.0, 49.0))

func _clamp(p: CharacterBody3D):
    p.position.x = clamp(p.position.x, -32.5, 32.5)
    p.position.z = clamp(p.position.z, -51.0, 51.0)

func _camera_follow(delta: float):
    var focus := (controlled.global_position + ball.global_position) * 0.5
    focus.x = clamp(focus.x, -27.0, 27.0)
    focus.z = clamp(focus.z, -44.0, 44.0)
    var desired := focus + Vector3(21, 13, 15)
    camera.global_position = camera.global_position.lerp(desired, min(delta * 2.5, 1.0))
    camera.look_at(focus, Vector3.UP)

func _clock():
    var sec := int(match_time)
    time_label.text = "%02d:%02d" % [sec / 60, sec % 60]

func _finish():
    finished = true
    ball.linear_velocity = Vector3.ZERO
    for p in home + away:
        p.velocity = Vector3.ZERO
    message_label.text = "FIM DE JOGO\nINT %d x %d GRE" % [score_home, score_away]
