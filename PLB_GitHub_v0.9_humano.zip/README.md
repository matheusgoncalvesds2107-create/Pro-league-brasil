# Pro League Brasil v0.9 — Jogadores Humanos

Primeira build sem cápsulas visuais: jogadores 3D leves com cabeça, tronco, braços, pernas, chuteiras e animação procedural de corrida. Mantém 11x11, bola, câmera, passe, chute, corrida e troca de jogador.
