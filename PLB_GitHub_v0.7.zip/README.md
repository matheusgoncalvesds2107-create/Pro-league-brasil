# Pro League Brasil — PLB v0.7

Primeiro protótipo jogável Android do **Pro League Brasil**.

## Teste atual
- Internacional x Grêmio
- GRENAL DOS SÉCULOS / PLB TV
- 11 x 11
- passe, chute, corrida e troca de jogador
- IA básica, goleiros, marcação e regras/reinícios básicos
- câmera TV aproximada
- alvo de 30 FPS e renderizador Compatibility para celulares mais fracos
- partida de teste de 6 minutos

## APK
O GitHub Actions gera automaticamente um APK de teste na aba **Actions**. Abra o workflow **Build PLB APK**, entre na execução concluída e baixe o artefato **PLB-v0.7-APK**.

> Esta é uma versão de teste. Modelos, uniformes, torcida e regras ainda serão refinados nas próximas versões.
